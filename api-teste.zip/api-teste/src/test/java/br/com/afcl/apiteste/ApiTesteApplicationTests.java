package br.com.afcl.apiteste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
